This project is no longer maintained. Please use our new driver sdk [rslidar_sdk](https://github.com/RoboSense-LiDAR/rslidar_sdk). 

[rslidar_sdk](https://github.com/RoboSense-LiDAR/rslidar_sdk) supports ROS, ROS2, protobuf, and you can even use driver core [rs_driver](https://github.com/RoboSense-LiDAR/rs_driver) in Windows.

[rs_driver](https://github.com/RoboSense-LiDAR/rs_driver) supports all kind of RoboSense's lidars by now.
